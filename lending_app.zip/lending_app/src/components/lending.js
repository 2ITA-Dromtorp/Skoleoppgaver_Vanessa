import React from 'react'
import './../App.css'
import { useState, useEffect } from 'react';
import { useNavigate, useParams } from "react-router-dom";
import back from './../images/back.png';
import { Link, useSearchParams } from 'react-router-dom'

function Lending() {
  const [searchParams] = useSearchParams("")
  const [utstyr, setUtstyr] = useState(searchParams.get("utstyr"));
  const [elev, setElev] = useState("");
  const [dato, setDato] = useState("");
  
  const {id} = useParams()
  const navigate = useNavigate()
console.log()


  const handleSubmit = (e) => {

    e.preventDefault()

    fetch('/api/lending' +id, {
        method:'PUT',
        headers:{
          "content-type":"application/json",
        },
        body:JSON.stringify({"UtstyrID":utstyr, "ElevID":elev, "Dato":dato }),
    })
    .then(res => 
        {console.log(res.data)
        navigate('/home')
        }).catch(err => console.log(err)) 

}

  return (
    <div>

    <navbartop>
        <Link to="/home" className='back' ><img src={back} alt="logo"/><p>Hjem</p></Link>
    </navbartop>
      
    <navbar>Lån Utstyr</navbar>

    <div className='lending'>

        <div className='content'>
            <div className='lending-form'>
              <form  onSubmit={handleSubmit} action='/' method='POST'>
                  <div className='form-group1'>
                      <label htmlFor="">Utstyr:</label>
                      <input type="text"className='form-control' onChange={(e) => setUtstyr(e.target.value)}/>
                  </div>
                  <div className='form-group1'>
                      <label htmlFor="">Elev:</label>
                      <input type="text" className='form-control' onChange={(e) => setElev(e.target.value)}/>
                  </div>
                  <div className='form-group1'>
                      <label htmlFor="">Dato:</label>
                      <input type="date" className='form-control' onChange={(e) => setDato(e.target.value)}/>
                  </div>
                

                <button>Send forespørsel</button>
                </form>
            </div>
        </div>
    </div>
    </div>
  )
}

export default Lending