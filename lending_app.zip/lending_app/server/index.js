const express = require('express')
const port = process.env.PORT || 8080
const app = express()
app.use(express.static("build"));
app.use(express.json());
const cors = require("cors")
app.use(cors());

const bcrypt = require("bcrypt")
const saltRounds = 10;
const mysql = require('mysql2');

 
const dbConfig = {
    user: 'root',
    password: 'root',
    database: 'dromtorp',
    host: 'localhost',
    port: 8889,
}
 
const connection = mysql.createConnection(dbConfig);
connection.connect();
connection.connect((err) => {   if (err) { 
    console.error('Error connecting to database:', err.stack);     
    return;}   
    console.log('Connected to database.'); });

app.listen(port, () => console.log("Server started" + port))


// For å vise utstyr på home.js
app.get('/api/home', (request, response) => {
    connection.connect( function (err) {
      if (err) {
        console.error('error connecting: ' + err.stack);
        return;
      }
      console.log('connected as id ' + connection.threadId);
    }
    );
    connection.query('SELECT UtstyrID, UtstyrNavn FROM UtstyrTabell', function (error, results, fields) {
      if (error) throw error;
      console.log('The solution is: ', JSON.stringify(results));
      response.send(JSON.stringify(results))
    });
    
  })
 
  // For å vise utstyr som er utlånt på utlan.js
  app.get('/api/borrowed', (request, response) => {
    connection.connect( function (err) {
      if (err) {
        console.error('error connecting: ' + err.stack);
        return;
      }
      console.log('connected as id ' + connection.threadId);
    }
    );
    connection.query('SELECT UtstyrID, ElevID, Dato FROM UtlanTabell', function (error, results, fields) {
      if (error) throw error;
      console.log('The solution is: ', JSON.stringify(results));
      response.send(JSON.stringify(results))
    });
    
  })
// elev login på login.js
app.post('/api/login',(req, res) => {
    const b = req.body
    const query = 'SELECT passord FROM ElevTabell WHERE brukernavn = ?'
    const values = [b.brukernavn]
    console.log(query, values)
    connection.query(query, values, (err, result) => {
        if (err){
            console.log(err)
            res.status(500).send(err)
        } else {
            console.log(result)
            if (result[0].passord === b.passord) {
                res.status(200).send(result)  
            } else {
                res.status(401).send(err)
            }
        }
    })
})
// lærer login på login.js
app.post('/api/adminLogin',(req, res) => {
    const b = req.body
    const query = 'SELECT larerPassord FROM LarerTabell WHERE larerBrukernavn = ?'
    const values = [b.larerBrukernavn]
    console.log(query, values)
    connection.query(query, values, (err, result) => {
        if (err){
            console.log(err)
            res.status(500).send(err)
        } else {
            console.log(result)
            if (result[0].larerPassord === b.larerPassord) {
                res.status(200).send(result)  
            } else {
                res.status(401).send(err)
            }
        }
    })
})
// For å se elever i elever.js
app.get('/api/student', (request, response) => {
    connection.connect( function (err) {
      if (err) {
        console.error('error connecting: ' + err.stack);
        return;
      }
      console.log('connected as id ' + connection.threadId);
    }
    );
    connection.query('SELECT elevID, brukernavn, fornavn, etternavn, telefon, elevMail, klasseID FROM ElevTabell', function (error, results, fields) {
      if (error) throw error;
      console.log('The solution is: ', JSON.stringify(results));
      response.send(JSON.stringify(results))
    });
    
  })
  

app.get('/api/equipment', (request, response) => {
    const [results] = await connection.query(
        'SELECT utstyrID FROM UtstyrTabell WHERE `UtstyrID` = 1',
      );   
      response.send(JSON.stringify(results))
   
   
})


// For å oppdatere utstyr data i databasen
app.put('/lending/:id', (request, response) => {
    const sql = "UPDATE UtlanTabell SET ElevID = ?, Dato = ?, WHERE UtstyrID = ?";
    const id = request.params.id;
    const { ElevID, Dato } = request.body;
    const values = [ElevID, Dato, id];
    connection.query(sql, values, (error, data) => {
      if (error) {
        console.log(error)
        return response.status(500).json({ error: error.message })
        }
        else{
          return response.json(data)
        }
      })
  })
/*
app.post('/bookKurs',(req, res) => {
    const b = req.body
    const query = 'SELECT userKurs FROM login WHERE userName = ? AND userMail = ? AND userNumber = ?'
    const values = [b.username, b.mail, b.number]
    connection.query(query, values, (err, result) => {
        if (err){
            console.log(err)
            res.status(500).send(err)
        } else {
            if (result.length > 0) {
                let kurs = result[0].userKurs
                console.log(kurs)
                kurs = JSON.parse(kurs)

                
                if (kurs.includes(b.kurs)) {
                    res.status(409).json("Du er allerede påmeldt dette kurset, naviger tilbake til forside")
                    return (
                        console.log("Kurs book")
                    )
                }
                kurs.push(b.kurs)
                kurs = JSON.stringify(kurs)
                console.log(kurs) + "ggmmjgmh"


                const query = 'UPDATE login SET userKurs = ? WHERE userName = ? AND userMail = ? AND userNumber = ?'
                const values = [kurs, b.username, b.mail, b.number]
                connection.query(query, values, (checkerr, checkresult) => {
                    if (checkerr){
                        console.log(checkerr)
                        res.status(500).send(checkerr)
                    } else {
                        res.status(200).send(checkresult)  
                    }
                })
            } else {
                res.status(401).send(err)
            }
        }
    })
})
app.post('/create-user',(req, res) => {
    const b = req.body
    if (b.fornavn.length < 1 || b.etternavn.length < 1 || b.telefon.length < 1 || b.klasseID.length < 1 || b.brukernavn.length < 1 || b.passord.length < 1 || b.elevMail.length < 1 ) {
        res.status(400).json("Error")
        return;
    }
    const number = parseInt(b.number)
    const query = 'INSERT INTO ElevTabell ( elevID, fornavn, etternavn, telefon, klasseID, brukernavn, passord, elevMail, utstyrID ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    const values = [null, b.username, number, b.mail, b.passord, "[]"]
    console.log(query, values)
    connection.query(query, values, (err, result) => {
        if (err){
            console.log(err)
            res.status(500).send(err)
        } else {
            res.status(200).send(result)  
        }
    })
})
*/